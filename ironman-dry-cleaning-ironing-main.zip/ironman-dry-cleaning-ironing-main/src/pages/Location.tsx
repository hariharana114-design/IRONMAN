import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import LocationSection from '@/components/LocationSection';
import { Truck, Clock, MapPin, Star } from 'lucide-react';

const serviceAreas = [
  "Anna Nagar", "T. Nagar", "Adyar", "Velachery", "Mylapore", "Nungambakkam",
  "Kodambakkam", "Vadapalani", "Guindy", "Tambaram", "Porur", "Koyambedu",
  "Egmore", "Royapettah", "Kilpauk", "Ashok Nagar", "Besant Nagar", "Thiruvanmiyur",
  "Keelkattalai", "Madipakkam"
];

const Location = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-28 pb-16">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-16">
            <span className="text-primary font-medium text-sm tracking-widest uppercase">Location</span>
            <h1 className="text-4xl md:text-6xl font-bold mt-4">
              <span className="text-foreground">Serving </span>
              <span className="text-gradient-gold">Chennai</span>
            </h1>
            <p className="text-muted-foreground mt-4 max-w-2xl mx-auto text-lg">
              Premium dry cleaning service across Chennai with free pickup & delivery
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
            <div className="bg-card border border-border rounded-2xl p-6 text-center">
              <div className="w-12 h-12 rounded-full gradient-ironman flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <p className="text-3xl font-bold text-gradient-gold">18+</p>
              <p className="text-muted-foreground text-sm">Areas Covered</p>
            </div>
            <div className="bg-card border border-border rounded-2xl p-6 text-center">
              <div className="w-12 h-12 rounded-full gradient-ironman flex items-center justify-center mx-auto mb-4">
                <Truck className="w-6 h-6 text-white" />
              </div>
              <p className="text-3xl font-bold text-gradient-gold">Free</p>
              <p className="text-muted-foreground text-sm">Pickup & Delivery</p>
            </div>
            <div className="bg-card border border-border rounded-2xl p-6 text-center">
              <div className="w-12 h-12 rounded-full gradient-ironman flex items-center justify-center mx-auto mb-4">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <p className="text-3xl font-bold text-gradient-gold">24hr</p>
              <p className="text-muted-foreground text-sm">Express Available</p>
            </div>
            <div className="bg-card border border-border rounded-2xl p-6 text-center">
              <div className="w-12 h-12 rounded-full gradient-ironman flex items-center justify-center mx-auto mb-4">
                <Star className="w-6 h-6 text-white" />
              </div>
              <p className="text-3xl font-bold text-gradient-gold">5000+</p>
              <p className="text-muted-foreground text-sm">Happy Customers</p>
            </div>
          </div>

          {/* Service Areas */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center mb-8 text-foreground">Service Areas in Chennai</h2>
            <div className="flex flex-wrap justify-center gap-3">
              {serviceAreas.map((area, index) => (
                <span 
                  key={index}
                  className="px-4 py-2 bg-card border border-border rounded-full text-foreground hover:border-primary hover:text-primary transition-colors"
                >
                  {area}
                </span>
              ))}
            </div>
            <p className="text-center text-muted-foreground mt-6">
              Can't find your area? Contact us - we're expanding daily!
            </p>
          </div>
        </div>

        {/* Location Section */}
        <LocationSection />
      </main>

      <Footer />
    </div>
  );
};

export default Location;
