import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Zap, Package, Clock, CheckCircle, Loader2, CreditCard } from 'lucide-react';
import { Navigate } from 'react-router-dom';
import PaymentModal from '@/components/PaymentModal';

interface Order {
  id: string;
  service_type: string;
  items_count: number;
  pickup_date: string;
  delivery_date: string | null;
  status: string;
  total_amount: number | null;
  notes: string | null;
  created_at: string;
}

interface Profile {
  full_name: string | null;
  phone: string | null;
  address: string | null;
}

const Dashboard = () => {
  const { user, loading } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isCreatingOrder, setIsCreatingOrder] = useState(false);
  const [loadingData, setLoadingData] = useState(true);

  // New order form
  const [serviceType, setServiceType] = useState('');
  const [itemsCount, setItemsCount] = useState('1');
  const [pickupDate, setPickupDate] = useState('');
  const [notes, setNotes] = useState('');
  
  // Payment modal state
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [selectedOrderForPayment, setSelectedOrderForPayment] = useState<Order | null>(null);

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    try {
      // Fetch profile
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user?.id)
        .single();
      
      if (profileData) {
        setProfile(profileData);
      }

      // Fetch orders
      const { data: ordersData } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });
      
      if (ordersData) {
        setOrders(ordersData);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoadingData(false);
    }
  };

  const handleCreateOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!serviceType || !pickupDate) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsCreatingOrder(true);
    try {
      const { error } = await supabase.from('orders').insert({
        user_id: user?.id,
        service_type: serviceType,
        items_count: parseInt(itemsCount),
        pickup_date: pickupDate,
        notes: notes || null,
      });

      if (error) throw error;

      toast.success('Order created successfully!');
      setServiceType('');
      setItemsCount('1');
      setPickupDate('');
      setNotes('');
      fetchData();
    } catch (error: any) {
      toast.error(error.message || 'Failed to create order');
    } finally {
      setIsCreatingOrder(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4 text-secondary" />;
      case 'processing':
        return <Package className="w-4 h-4 text-primary" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      default:
        return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  // Get the latest active order for status tracking
  const latestOrder = orders.find(order => order.status !== 'completed') || orders[0];
  
  const orderStatuses = ['pending', 'picked-up', 'processing', 'cleaning', 'ready', 'delivered'];
  
  const getStatusStep = (status: string) => {
    const statusMap: Record<string, number> = {
      'pending': 0,
      'picked-up': 1,
      'processing': 2,
      'cleaning': 3,
      'ready': 4,
      'delivered': 5,
      'completed': 5
    };
    return statusMap[status] ?? 0;
  };

  const statusLabels = ['Pending', 'Picked Up', 'Processing', 'Cleaning', 'Ready', 'Delivered'];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-28 pb-16">
        <div className="container mx-auto px-4">
          {/* Welcome Section */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">
              <span className="text-foreground">Welcome, </span>
              <span className="text-gradient-gold">{profile?.full_name || 'Hero'}</span>
            </h1>
            <p className="text-muted-foreground">Manage your dry cleaning orders here</p>
          </div>

          {/* Order Status Tracker */}
          {latestOrder && (
            <Card className="bg-card border-border mb-8">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-foreground">
                  <Package className="w-5 h-5 text-primary" />
                  Order Status - {latestOrder.service_type.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </CardTitle>
                <CardDescription>
                  Order placed on {new Date(latestOrder.created_at).toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* Status Timeline */}
                <div className="relative">
                  {/* Progress Line */}
                  <div className="absolute top-5 left-0 right-0 h-1 bg-muted rounded-full">
                    <div 
                      className="h-full bg-gradient-to-r from-primary to-secondary rounded-full transition-all duration-500"
                      style={{ width: `${(getStatusStep(latestOrder.status) / (orderStatuses.length - 1)) * 100}%` }}
                    />
                  </div>
                  
                  {/* Status Steps */}
                  <div className="relative flex justify-between">
                    {statusLabels.map((label, index) => {
                      const currentStep = getStatusStep(latestOrder.status);
                      const isCompleted = index <= currentStep;
                      const isCurrent = index === currentStep;
                      
                      return (
                        <div key={label} className="flex flex-col items-center">
                          <div 
                            className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                              isCompleted 
                                ? 'bg-primary border-primary text-white' 
                                : 'bg-card border-border text-muted-foreground'
                            } ${isCurrent ? 'ring-4 ring-primary/30 scale-110' : ''}`}
                          >
                            {isCompleted ? (
                              <CheckCircle className="w-5 h-5" />
                            ) : (
                              <span className="text-sm font-medium">{index + 1}</span>
                            )}
                          </div>
                          <span className={`text-xs mt-2 text-center max-w-[60px] ${
                            isCompleted ? 'text-foreground font-medium' : 'text-muted-foreground'
                          }`}>
                            {label}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Current Status Info */}
                <div className="mt-8 p-4 bg-muted rounded-xl border border-border">
                  <div className="flex items-center justify-between flex-wrap gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Current Status</p>
                      <p className="text-lg font-semibold text-foreground capitalize">
                        {latestOrder.status.replace('-', ' ')}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Items</p>
                      <p className="text-lg font-semibold text-foreground">
                        {latestOrder.items_count} item{latestOrder.items_count > 1 ? 's' : ''}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Pickup Date</p>
                      <p className="text-lg font-semibold text-foreground">
                        {new Date(latestOrder.pickup_date).toLocaleDateString()}
                      </p>
                    </div>
                    {latestOrder.delivery_date && (
                      <div>
                        <p className="text-sm text-muted-foreground">Delivery Date</p>
                        <p className="text-lg font-semibold text-foreground">
                          {new Date(latestOrder.delivery_date).toLocaleDateString()}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Create Order */}
            <div className="lg:col-span-1">
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-foreground">
                    <Zap className="w-5 h-5 text-primary" />
                    New Order
                  </CardTitle>
                  <CardDescription>Schedule a pickup for your garments</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleCreateOrder} className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-foreground">Service Type</Label>
                      <Select value={serviceType} onValueChange={setServiceType}>
                        <SelectTrigger className="bg-input border-border">
                          <SelectValue placeholder="Select service" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="dry-cleaning">Dry Cleaning</SelectItem>
                          <SelectItem value="steam-ironing">Steam Ironing</SelectItem>
                          <SelectItem value="laundry">Laundry Service</SelectItem>
                          <SelectItem value="stain-removal">Stain Removal</SelectItem>
                          <SelectItem value="express">Express Service</SelectItem>
                          <SelectItem value="premium">Premium Care</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-foreground">Number of Items</Label>
                      <Input
                        type="number"
                        min="1"
                        value={itemsCount}
                        onChange={(e) => setItemsCount(e.target.value)}
                        className="bg-input border-border"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-foreground">Pickup Date</Label>
                      <Input
                        type="date"
                        value={pickupDate}
                        onChange={(e) => setPickupDate(e.target.value)}
                        min={new Date().toISOString().split('T')[0]}
                        className="bg-input border-border"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-foreground">Notes (Optional)</Label>
                      <Textarea
                        placeholder="Special instructions..."
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        className="bg-input border-border"
                      />
                    </div>

                    <Button
                      type="submit"
                      className="w-full gradient-ironman text-white glow-red"
                      disabled={isCreatingOrder}
                    >
                      {isCreatingOrder ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Zap className="w-4 h-4 mr-2" />
                      )}
                      Create Order
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Orders List */}
            <div className="lg:col-span-2">
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-foreground">
                    <Package className="w-5 h-5 text-secondary" />
                    Your Orders
                  </CardTitle>
                  <CardDescription>Track your dry cleaning orders</CardDescription>
                </CardHeader>
                <CardContent>
                  {loadingData ? (
                    <div className="flex items-center justify-center py-12">
                      <Loader2 className="w-8 h-8 animate-spin text-primary" />
                    </div>
                  ) : orders.length === 0 ? (
                    <div className="text-center py-12">
                      <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">No orders yet. Create your first order!</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {orders.map((order) => (
                        <div
                          key={order.id}
                          className="bg-muted rounded-xl p-4 border border-border hover:border-primary transition-colors"
                        >
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <h3 className="font-semibold text-foreground capitalize">
                                {order.service_type.replace(/-/g, ' ')}
                              </h3>
                              <p className="text-sm text-muted-foreground">
                                {order.items_count} item{order.items_count > 1 ? 's' : ''}
                              </p>
                            </div>
                            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-card border border-border">
                              {getStatusIcon(order.status)}
                              <span className="text-sm capitalize text-foreground">{order.status}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span>Pickup: {new Date(order.pickup_date).toLocaleDateString()}</span>
                            {order.delivery_date && (
                              <span>Delivery: {new Date(order.delivery_date).toLocaleDateString()}</span>
                            )}
                          </div>
                          {order.notes && (
                            <p className="text-sm text-muted-foreground mt-2 italic">"{order.notes}"</p>
                          )}
                          {order.status === 'pending' && (
                            <Button
                              size="sm"
                              className="mt-3 gradient-ironman text-white"
                              onClick={() => {
                                setSelectedOrderForPayment(order);
                                setPaymentModalOpen(true);
                              }}
                            >
                              <CreditCard className="w-4 h-4 mr-2" />
                              Pay Now
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
      
      {/* Payment Modal */}
      {selectedOrderForPayment && (
        <PaymentModal
          isOpen={paymentModalOpen}
          onClose={() => {
            setPaymentModalOpen(false);
            setSelectedOrderForPayment(null);
          }}
          orderId={selectedOrderForPayment.id}
          amount={selectedOrderForPayment.items_count * 100} // ₹100 per item as base price
          serviceType={selectedOrderForPayment.service_type}
          onSuccess={fetchData}
        />
      )}
    </div>
  );
};

export default Dashboard;
