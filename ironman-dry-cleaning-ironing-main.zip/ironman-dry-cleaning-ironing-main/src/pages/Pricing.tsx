import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Check, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const pricingCategories = [
  {
    title: "Everyday Wear",
    items: [
      { name: "Shirt / T-Shirt", price: "₹49" },
      { name: "Pants / Trousers", price: "₹69" },
      { name: "Jeans", price: "₹79" },
      { name: "Shorts", price: "₹49" },
      { name: "Dress", price: "₹149" },
      { name: "Skirt", price: "₹79" },
    ]
  },
  {
    title: "Formal Wear",
    items: [
      { name: "Suit (2 piece)", price: "₹349" },
      { name: "Suit (3 piece)", price: "₹449" },
      { name: "Blazer", price: "₹199" },
      { name: "Formal Shirt", price: "₹79" },
      { name: "Tie", price: "₹49" },
      { name: "Waistcoat", price: "₹129" },
    ]
  },
  {
    title: "Traditional Wear",
    items: [
      { name: "Saree (Plain)", price: "₹149" },
      { name: "Saree (Silk/Heavy)", price: "₹299" },
      { name: "Salwar Kameez", price: "₹199" },
      { name: "Kurta", price: "₹99" },
      { name: "Sherwani", price: "₹449" },
      { name: "Lehenga", price: "₹599" },
    ]
  },
  {
    title: "Home & Bedding",
    items: [
      { name: "Bedsheet (Single)", price: "₹99" },
      { name: "Bedsheet (Double)", price: "₹149" },
      { name: "Blanket", price: "₹249" },
      { name: "Curtains (per panel)", price: "₹149" },
      { name: "Pillow Cover", price: "₹39" },
      { name: "Comforter", price: "₹399" },
    ]
  }
];

const packages = [
  {
    name: "Arc Starter",
    price: "₹999",
    period: "per month",
    description: "Perfect for individuals",
    features: [
      "10 garments per month",
      "Free pickup & delivery",
      "48-hour turnaround",
      "Basic stain removal",
      "Email support"
    ],
    popular: false
  },
  {
    name: "Iron Elite",
    price: "₹2,499",
    period: "per month",
    description: "Best for families",
    features: [
      "30 garments per month",
      "Priority pickup & delivery",
      "24-hour express included",
      "Advanced stain removal",
      "Premium packaging",
      "Phone support"
    ],
    popular: true
  },
  {
    name: "Stark Premium",
    price: "₹4,999",
    period: "per month",
    description: "Ultimate care package",
    features: [
      "Unlimited garments",
      "Same-day service",
      "24/7 pickup available",
      "Premium care included",
      "Luxury packaging",
      "Dedicated account manager"
    ],
    popular: false
  }
];

const Pricing = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-28 pb-16">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-16">
            <span className="text-primary font-medium text-sm tracking-widest uppercase">Pricing</span>
            <h1 className="text-4xl md:text-6xl font-bold mt-4">
              <span className="text-foreground">Transparent </span>
              <span className="text-gradient-gold">Pricing</span>
            </h1>
            <p className="text-muted-foreground mt-4 max-w-2xl mx-auto text-lg">
              No hidden charges. Quality service at fair prices.
            </p>
          </div>

          {/* Subscription Packages */}
          <div className="mb-20">
            <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Monthly Packages</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {packages.map((pkg, index) => (
                <div 
                  key={index}
                  className={`relative bg-card border rounded-2xl p-8 ${
                    pkg.popular ? 'border-primary glow-red' : 'border-border'
                  }`}
                >
                  {pkg.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 gradient-ironman rounded-full text-white text-sm font-medium">
                      Most Popular
                    </div>
                  )}
                  
                  <h3 className="text-2xl font-bold text-foreground mb-2">{pkg.name}</h3>
                  <p className="text-muted-foreground text-sm mb-4">{pkg.description}</p>
                  
                  <div className="mb-6">
                    <span className="text-4xl font-bold text-gradient-gold">{pkg.price}</span>
                    <span className="text-muted-foreground"> {pkg.period}</span>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {pkg.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-2 text-foreground">
                        <Check className="w-5 h-5 text-secondary" />
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <Link to="/auth">
                    <Button 
                      className={`w-full ${
                        pkg.popular 
                          ? 'gradient-ironman text-white glow-red' 
                          : 'bg-muted text-foreground hover:bg-muted/80'
                      }`}
                    >
                      Get Started
                    </Button>
                  </Link>
                </div>
              ))}
            </div>
          </div>

          {/* Individual Pricing */}
          <div>
            <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Individual Pricing</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {pricingCategories.map((category, index) => (
                <div 
                  key={index}
                  className="bg-card border border-border rounded-2xl p-8"
                >
                  <h3 className="text-xl font-bold text-gradient-gold mb-6">{category.title}</h3>
                  <div className="space-y-4">
                    {category.items.map((item, i) => (
                      <div key={i} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                        <span className="text-foreground">{item.name}</span>
                        <span className="text-secondary font-semibold">{item.price}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Note */}
          <div className="mt-12 text-center">
            <p className="text-muted-foreground text-sm">
              * All prices are subject to GST. Express service charges additional 50%.
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Pricing;
