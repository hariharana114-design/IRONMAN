import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Shirt, Wind, Sparkles, Package, Timer, Shield, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const services = [
  {
    icon: Shirt,
    title: "Dry Cleaning",
    description: "Premium solvent cleaning for delicate fabrics, suits, formal wear, and designer clothes. Our eco-friendly process removes stains while preserving fabric integrity.",
    features: ["Eco-friendly solvents", "Gentle on fabrics", "Perfect for suits & gowns", "Stain pre-treatment included"],
    price: "From ₹99 per item"
  },
  {
    icon: Wind,
    title: "Steam Ironing",
    description: "Professional pressing service using advanced steam technology. Get crisp, wrinkle-free clothes with perfect creases every time.",
    features: ["High-temperature steam", "Perfect creases", "Safe for all fabrics", "Quick turnaround"],
    price: "From ₹49 per item"
  },
  {
    icon: Sparkles,
    title: "Stain Removal",
    description: "Specialized treatment for tough stains including wine, oil, ink, and grass. Our arc-tech process tackles even the most stubborn marks.",
    features: ["Advanced stain analysis", "Specialized treatments", "Fabric-safe solutions", "Guaranteed results"],
    price: "From ₹149 per item"
  },
  {
    icon: Package,
    title: "Laundry Service",
    description: "Complete wash, dry, and fold service for your everyday clothes. Fresh, clean, and neatly folded - ready to wear.",
    features: ["Wash & fold", "Premium detergents", "Fabric softener", "Separate whites & colors"],
    price: "From ₹79 per kg"
  },
  {
    icon: Timer,
    title: "Express Service",
    description: "Need it fast? Our express service delivers clean clothes in just 24 hours. Perfect for urgent needs and last-minute events.",
    features: ["24-hour delivery", "Priority processing", "Same-day pickup", "Rush availability"],
    price: "From ₹199 per item"
  },
  {
    icon: Shield,
    title: "Premium Care",
    description: "Specialized treatment for luxury fabrics, wedding dresses, and designer wear. White-glove service for your most precious garments.",
    features: ["Hand finishing", "Luxury packaging", "Insurance included", "Expert handling"],
    price: "From ₹299 per item"
  }
];

const Services = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-28 pb-16">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-16">
            <span className="text-primary font-medium text-sm tracking-widest uppercase">Our Services</span>
            <h1 className="text-4xl md:text-6xl font-bold mt-4">
              <span className="text-foreground">Superhero-Level </span>
              <span className="text-gradient-gold">Cleaning</span>
            </h1>
            <p className="text-muted-foreground mt-4 max-w-2xl mx-auto text-lg">
              From everyday laundry to premium garment care, experience the future of dry cleaning with Ironman technology
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            {services.map((service, index) => (
              <div 
                key={index}
                className="bg-card border border-border rounded-2xl p-8 hover:border-primary transition-all duration-300 group"
              >
                <div className="flex items-start gap-6">
                  <div className="w-16 h-16 rounded-xl gradient-ironman flex items-center justify-center flex-shrink-0 group-hover:glow-red transition-all">
                    <service.icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-foreground mb-2">{service.title}</h3>
                    <p className="text-muted-foreground mb-4">{service.description}</p>
                    
                    <ul className="space-y-2 mb-4">
                      {service.features.map((feature, i) => (
                        <li key={i} className="flex items-center gap-2 text-sm text-foreground">
                          <Star className="w-4 h-4 text-secondary" />
                          {feature}
                        </li>
                      ))}
                    </ul>

                    <p className="text-secondary font-bold text-xl">{service.price}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* CTA */}
          <div className="text-center">
            <div className="inline-block bg-card border border-border rounded-2xl p-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">Ready to experience the difference?</h2>
              <p className="text-muted-foreground mb-6">Book your first order today and get 20% off!</p>
              <Link to="/auth">
                <Button size="lg" className="gradient-ironman text-white glow-red">
                  Book Now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Services;
