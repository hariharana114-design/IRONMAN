import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Package, Clock, Sparkles, Truck, CheckCircle, MapPin } from 'lucide-react';
import { Navigate } from 'react-router-dom';

interface Order {
  id: string;
  service_type: string;
  items_count: number;
  pickup_date: string;
  delivery_date: string | null;
  status: string;
  total_amount: number | null;
  notes: string | null;
  created_at: string;
}

const statusSteps = [
  { key: 'pending', label: 'Order Placed', icon: Clock, description: 'Your order has been received' },
  { key: 'picked_up', label: 'Picked Up', icon: Package, description: 'Items collected from your location' },
  { key: 'processing', label: 'Processing', icon: Sparkles, description: 'Your items are being cleaned' },
  { key: 'ready', label: 'Ready', icon: CheckCircle, description: 'Cleaning complete, ready for delivery' },
  { key: 'out_for_delivery', label: 'Out for Delivery', icon: Truck, description: 'On the way to you' },
  { key: 'completed', label: 'Delivered', icon: MapPin, description: 'Successfully delivered' },
];

const OrderTracking = () => {
  const { user, loading } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  useEffect(() => {
    if (user) {
      fetchOrders();
      
      // Set up realtime subscription
      const channel = supabase
        .channel('order-updates')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'orders',
            filter: `user_id=eq.${user.id}`,
          },
          (payload) => {
            console.log('Realtime update:', payload);
            if (payload.eventType === 'UPDATE') {
              setOrders((prev) =>
                prev.map((order) =>
                  order.id === payload.new.id ? { ...order, ...payload.new } : order
                )
              );
              if (selectedOrder?.id === payload.new.id) {
                setSelectedOrder({ ...selectedOrder, ...payload.new });
              }
            } else if (payload.eventType === 'INSERT') {
              setOrders((prev) => [payload.new as Order, ...prev]);
            }
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [user]);

  const fetchOrders = async () => {
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      if (data) {
        setOrders(data);
        if (data.length > 0) {
          setSelectedOrder(data[0]);
        }
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoadingOrders(false);
    }
  };

  const getStatusIndex = (status: string) => {
    return statusSteps.findIndex((step) => step.key === status);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-secondary/20 text-secondary border-secondary';
      case 'picked_up':
      case 'processing':
        return 'bg-primary/20 text-primary border-primary';
      case 'ready':
      case 'out_for_delivery':
        return 'bg-blue-500/20 text-blue-400 border-blue-500';
      case 'completed':
        return 'bg-green-500/20 text-green-400 border-green-500';
      default:
        return 'bg-muted text-muted-foreground border-border';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="pt-28 pb-16">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="mb-12 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              <span className="text-gradient-gold">Track Your Orders</span>
            </h1>
            <p className="text-muted-foreground text-lg">
              Real-time updates on your dry cleaning orders
            </p>
            <div className="flex items-center justify-center gap-2 mt-4">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-sm text-green-400">Live updates enabled</span>
            </div>
          </div>

          {loadingOrders ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : orders.length === 0 ? (
            <Card className="bg-card border-border max-w-md mx-auto">
              <CardContent className="py-12 text-center">
                <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-2">No Orders Yet</h3>
                <p className="text-muted-foreground">
                  Create your first order from the dashboard to start tracking!
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Orders List */}
              <div className="lg:col-span-1 space-y-4">
                <h2 className="text-xl font-semibold text-foreground mb-4">Your Orders</h2>
                {orders.map((order) => (
                  <Card
                    key={order.id}
                    className={`bg-card border-border cursor-pointer transition-all hover:border-primary ${
                      selectedOrder?.id === order.id ? 'border-primary ring-1 ring-primary' : ''
                    }`}
                    onClick={() => setSelectedOrder(order)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-semibold text-foreground capitalize">
                            {order.service_type.replace('-', ' ')}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {order.items_count} item{order.items_count > 1 ? 's' : ''}
                          </p>
                        </div>
                        <Badge className={`${getStatusColor(order.status)} border`}>
                          {order.status.replace('_', ' ')}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Ordered: {new Date(order.created_at).toLocaleDateString()}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Order Details & Timeline */}
              <div className="lg:col-span-2">
                {selectedOrder && (
                  <Card className="bg-card border-border">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-2xl capitalize text-foreground">
                            {selectedOrder.service_type.replace('-', ' ')}
                          </CardTitle>
                          <CardDescription>
                            Order ID: {selectedOrder.id.slice(0, 8)}...
                          </CardDescription>
                        </div>
                        <Badge className={`${getStatusColor(selectedOrder.status)} border text-sm px-3 py-1`}>
                          {selectedOrder.status.replace('_', ' ')}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {/* Order Info */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8 p-4 bg-muted rounded-xl">
                        <div>
                          <p className="text-sm text-muted-foreground">Items</p>
                          <p className="text-lg font-semibold text-foreground">{selectedOrder.items_count}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Pickup Date</p>
                          <p className="text-lg font-semibold text-foreground">
                            {new Date(selectedOrder.pickup_date).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Delivery Date</p>
                          <p className="text-lg font-semibold text-foreground">
                            {selectedOrder.delivery_date
                              ? new Date(selectedOrder.delivery_date).toLocaleDateString()
                              : 'TBD'}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Amount</p>
                          <p className="text-lg font-semibold text-gradient-gold">
                            {selectedOrder.total_amount ? `₹${selectedOrder.total_amount}` : 'TBD'}
                          </p>
                        </div>
                      </div>

                      {/* Status Timeline */}
                      <div className="relative">
                        <h3 className="text-lg font-semibold text-foreground mb-6">Order Progress</h3>
                        <div className="space-y-0">
                          {statusSteps.map((step, index) => {
                            const currentIndex = getStatusIndex(selectedOrder.status);
                            const isCompleted = index <= currentIndex;
                            const isCurrent = index === currentIndex;
                            const StepIcon = step.icon;

                            return (
                              <div key={step.key} className="flex gap-4">
                                {/* Timeline line and dot */}
                                <div className="flex flex-col items-center">
                                  <div
                                    className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                                      isCompleted
                                        ? 'bg-primary text-primary-foreground'
                                        : 'bg-muted text-muted-foreground'
                                    } ${isCurrent ? 'ring-4 ring-primary/30 animate-pulse' : ''}`}
                                  >
                                    <StepIcon className="w-5 h-5" />
                                  </div>
                                  {index < statusSteps.length - 1 && (
                                    <div
                                      className={`w-0.5 h-16 ${
                                        index < currentIndex ? 'bg-primary' : 'bg-border'
                                      }`}
                                    />
                                  )}
                                </div>

                                {/* Step content */}
                                <div className="pb-8">
                                  <h4
                                    className={`font-semibold ${
                                      isCompleted ? 'text-foreground' : 'text-muted-foreground'
                                    }`}
                                  >
                                    {step.label}
                                  </h4>
                                  <p className="text-sm text-muted-foreground">{step.description}</p>
                                  {isCurrent && (
                                    <span className="inline-flex items-center gap-1 mt-2 text-xs text-primary">
                                      <span className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse" />
                                      Current status
                                    </span>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Notes */}
                      {selectedOrder.notes && (
                        <div className="mt-6 p-4 bg-muted rounded-xl">
                          <p className="text-sm text-muted-foreground mb-1">Special Instructions</p>
                          <p className="text-foreground italic">"{selectedOrder.notes}"</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default OrderTracking;
