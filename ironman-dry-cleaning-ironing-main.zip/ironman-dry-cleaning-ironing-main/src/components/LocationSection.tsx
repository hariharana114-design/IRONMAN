import { MapPin, Phone, Clock, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';

const LocationSection = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 metallic-surface" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <span className="text-secondary font-medium text-sm tracking-widest uppercase">Visit Us</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-4">
            <span className="text-foreground">IRONMAN HQ - </span>
            <span className="text-gradient-gold">Chennai</span>
          </h2>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            Our state-of-the-art facilities across Chennai
          </p>
        </div>


        {/* Common Contact Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
          <div className="bg-card border border-border rounded-2xl p-6 flex items-center gap-4 hover:border-primary transition-colors">
            <div className="w-12 h-12 rounded-xl gradient-ironman flex items-center justify-center flex-shrink-0">
              <Mail className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-foreground mb-1">Email</h3>
              <p className="text-muted-foreground text-sm">ironmandrycleaning@gmail.com</p>
            </div>
          </div>
          <div className="bg-card border border-border rounded-2xl p-6 flex items-center gap-4 hover:border-primary transition-colors">
            <div className="w-12 h-12 rounded-xl gradient-ironman flex items-center justify-center flex-shrink-0">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-foreground mb-1">Sunday Hours</h3>
              <p className="text-muted-foreground text-sm">9:00 AM - 6:00 PM</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LocationSection;
