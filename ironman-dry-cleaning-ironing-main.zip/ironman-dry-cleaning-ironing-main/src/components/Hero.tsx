import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Zap, Shield, Clock, Sparkles } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background Effects */}
      <div className="absolute inset-0 metallic-surface" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full gradient-arc-reactor blur-3xl opacity-20" />
      
      {/* Arc Reactor */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className="w-32 h-32 rounded-full gradient-arc-reactor glow-arc" />
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          {/* Headline */}
          <div className="mb-6">
            <span className="inline-block px-4 py-2 rounded-full bg-primary/20 text-primary text-sm font-medium mb-4">
              🏆 Chennai's #1 Premium Dry Cleaning
            </span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="text-foreground">Powered by</span>
            <br />
            <span className="text-gradient-gold">IRONMAN</span>
            <br />
            <span className="text-primary">Technology</span>
          </h1>
          
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Experience the future of garment care. Our arc-reactor powered cleaning 
            technology delivers spotless results with superhero precision.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link to="/auth">
              <Button size="lg" className="gradient-ironman text-white glow-red text-lg px-8 py-6">
                <Zap className="w-5 h-5 mr-2" />
                Book Now
              </Button>
            </Link>
            <Link to="/services">
              <Button size="lg" variant="outline" className="border-secondary text-secondary hover:bg-secondary/10 text-lg px-8 py-6">
                View Services
              </Button>
            </Link>
          </div>

          {/* Feature Pills */}
          <div className="flex flex-wrap justify-center gap-4">
            {[
              { icon: Clock, text: '24-Hour Express' },
              { icon: Shield, text: '100% Safe' },
              { icon: Sparkles, text: 'Premium Quality' },
            ].map((feature) => (
              <div
                key={feature.text}
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-border hover:scale-105 transition-transform"
              >
                <feature.icon className="w-4 h-4 text-secondary" />
                <span className="text-sm text-foreground">{feature.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
};

export default Hero;
