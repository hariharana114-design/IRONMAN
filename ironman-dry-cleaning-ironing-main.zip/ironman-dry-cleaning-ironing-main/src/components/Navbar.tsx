import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { Menu, X, Zap } from 'lucide-react';
import { useState } from 'react';

const Navbar = () => {
  const { user, signOut } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 metallic-surface border-b border-border backdrop-blur-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full gradient-arc-reactor flex items-center justify-center glow-arc">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold text-gradient-gold">IRONMAN</span>
              <span className="text-xs text-muted-foreground tracking-widest">DRY CLEANING</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-2">
            <span className="text-sm text-muted-foreground mr-4">www.Ironmandrycleaning.com</span>
            <Link to="/">
              <Button variant="ghost" className="text-foreground hover:text-secondary hover:bg-muted">
                Home
              </Button>
            </Link>
            <Link to="/services">
              <Button variant="ghost" className="text-foreground hover:text-secondary hover:bg-muted">
                Services
              </Button>
            </Link>
            <Link to="/pricing">
              <Button variant="ghost" className="text-foreground hover:text-secondary hover:bg-muted">
                Pricing
              </Button>
            </Link>
            <Link to="/location">
              <Button variant="ghost" className="text-foreground hover:text-secondary hover:bg-muted">
                Location
              </Button>
            </Link>
            {user ? (
              <>
                <Link to="/dashboard">
                  <Button variant="ghost" className="text-foreground hover:text-secondary hover:bg-muted">
                    Dashboard
                  </Button>
                </Link>
                <Link to="/track">
                  <Button variant="ghost" className="text-foreground hover:text-secondary hover:bg-muted">
                    Track Order
                  </Button>
                </Link>
                <Button 
                  onClick={signOut}
                  className="gradient-ironman text-white hover:opacity-90 glow-red"
                >
                  Sign Out
                </Button>
              </>
            ) : (
              <Link to="/auth">
                <Button className="gradient-ironman text-white hover:opacity-90 glow-red">
                  Login / Sign Up
                </Button>
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-foreground"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <div className="flex flex-col gap-2">
              <span className="text-sm text-muted-foreground px-4 py-2">www.Ironmandrycleaning.com</span>
              <Link to="/" onClick={() => setIsMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start text-foreground">
                  Home
                </Button>
              </Link>
              <Link to="/services" onClick={() => setIsMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start text-foreground">
                  Services
                </Button>
              </Link>
              <Link to="/pricing" onClick={() => setIsMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start text-foreground">
                  Pricing
                </Button>
              </Link>
              <Link to="/location" onClick={() => setIsMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start text-foreground">
                  Location
                </Button>
              </Link>
              {user ? (
                <>
                  <Link to="/dashboard" onClick={() => setIsMenuOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start text-foreground">
                      Dashboard
                    </Button>
                  </Link>
                  <Link to="/track" onClick={() => setIsMenuOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start text-foreground">
                      Track Order
                    </Button>
                  </Link>
                  <Button 
                    onClick={() => { signOut(); setIsMenuOpen(false); }}
                    className="gradient-ironman text-white mx-4"
                  >
                    Sign Out
                  </Button>
                </>
              ) : (
                <Link to="/auth" onClick={() => setIsMenuOpen(false)}>
                  <Button className="gradient-ironman text-white mx-4 w-[calc(100%-2rem)]">
                    Login / Sign Up
                  </Button>
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
