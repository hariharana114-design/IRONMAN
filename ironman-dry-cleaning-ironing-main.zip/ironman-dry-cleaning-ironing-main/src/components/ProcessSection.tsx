import { Package, Truck, Sparkles, CheckCircle } from 'lucide-react';

const steps = [
  {
    icon: Package,
    title: "Schedule Pickup",
    description: "Book online or call us. Our Iron Fleet arrives at your doorstep.",
    number: "01"
  },
  {
    icon: Truck,
    title: "Collection",
    description: "We collect your garments with care and precision.",
    number: "02"
  },
  {
    icon: Sparkles,
    title: "Arc-Clean Process",
    description: "Advanced cleaning technology removes every stain.",
    number: "03"
  },
  {
    icon: CheckCircle,
    title: "Delivery",
    description: "Fresh, pressed garments delivered back to you.",
    number: "04"
  }
];

const ProcessSection = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 metallic-surface opacity-50" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <span className="text-secondary font-medium text-sm tracking-widest uppercase">How It Works</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-4">
            <span className="text-foreground">The </span>
            <span className="text-gradient-gold">IRONMAN</span>
            <span className="text-foreground"> Process</span>
          </h2>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            Four simple steps to superhero-clean clothes
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div 
              key={index}
              className="relative group"
            >
              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-16 left-[60%] w-full h-0.5 bg-gradient-to-r from-primary to-secondary opacity-30" />
              )}
              
              <div className="bg-card border border-border rounded-2xl p-8 hover:border-primary transition-all duration-300 group-hover:glow-red">
                {/* Number Badge */}
                <div className="absolute -top-4 -right-4 w-12 h-12 rounded-full gradient-ironman flex items-center justify-center text-white font-bold text-lg glow-red">
                  {step.number}
                </div>

                {/* Icon */}
                <div className="w-16 h-16 rounded-xl gradient-arc-reactor flex items-center justify-center mb-6 group-hover:glow-arc transition-all">
                  <step.icon className="w-8 h-8 text-white" />
                </div>

                <h3 className="text-xl font-bold text-foreground mb-3">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;
