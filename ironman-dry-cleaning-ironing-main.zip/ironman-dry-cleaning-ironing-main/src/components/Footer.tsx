import { Link } from 'react-router-dom';
import { Zap, Facebook, Instagram, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-card border-t border-border py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <Link to="/" className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-full gradient-arc-reactor flex items-center justify-center glow-arc">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold text-gradient-gold">IRONMAN</span>
                <span className="text-xs text-muted-foreground tracking-widest">DRY CLEANING</span>
              </div>
            </Link>
            <p className="text-muted-foreground text-sm">
              Chennai's premium dry cleaning service powered by superhero technology.
            </p>
            <div className="flex gap-4 mt-6">
              <a href="https://facebook.com/IronmanDrycleaning" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:gradient-ironman transition-all">
                <Facebook className="w-5 h-5 text-foreground" />
              </a>
              <a href="https://instagram.com/ironmandrycleaning" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:gradient-ironman transition-all">
                <Instagram className="w-5 h-5 text-foreground" />
              </a>
              <a href="https://twitter.com/Ironman_shop" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:gradient-ironman transition-all">
                <Twitter className="w-5 h-5 text-foreground" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-foreground font-bold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              <li><Link to="/" className="text-muted-foreground hover:text-secondary transition-colors">Home</Link></li>
              <li><Link to="/services" className="text-muted-foreground hover:text-secondary transition-colors">Services</Link></li>
              <li><Link to="/pricing" className="text-muted-foreground hover:text-secondary transition-colors">Pricing</Link></li>
              <li><Link to="/location" className="text-muted-foreground hover:text-secondary transition-colors">Location</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-foreground font-bold mb-6">Services</h3>
            <ul className="space-y-3">
              <li className="text-muted-foreground">Dry Cleaning</li>
              <li className="text-muted-foreground">Steam Ironing</li>
              <li className="text-muted-foreground">Stain Removal</li>
              <li className="text-muted-foreground">Express Service</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-foreground font-bold mb-6">Contact</h3>
            <ul className="space-y-3">
              <li className="text-muted-foreground"> ironmandrycleaning</li>
              <li className="text-muted-foreground"> keelkattalai, Chennai - 6000117</li>
              <li className="text-muted-foreground">+91 7305804756 / 7305809906</li>
              <li className="text-muted-foreground">ironmandrycleaning@gmail.com</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-12 pt-8 text-center">
          <p className="text-muted-foreground text-sm">
            © 2026 Ironman Dry Cleaning. All rights reserved. | www.Ironmandrycleaning.com
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
