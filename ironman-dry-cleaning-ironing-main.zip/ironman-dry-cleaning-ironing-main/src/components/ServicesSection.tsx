import { Shirt, Wind, Sparkles, Package, Timer, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const services = [
  {
    icon: Shirt,
    title: "Dry Cleaning",
    description: "Premium solvent cleaning for delicate fabrics and formal wear.",
    price: "From ₹99"
  },
  {
    icon: Wind,
    title: "Steam Ironing",
    description: "Professional pressing with precision steam technology.",
    price: "From ₹49"
  },
  {
    icon: Sparkles,
    title: "Stain Removal",
    description: "Advanced arc-tech stain elimination for stubborn marks.",
    price: "From ₹149"
  },
  {
    icon: Package,
    title: "Laundry Service",
    description: "Complete wash, dry, and fold service for everyday clothes.",
    price: "From ₹79"
  },
  {
    icon: Timer,
    title: "Express Service",
    description: "Same-day service for urgent cleaning needs.",
    price: "From ₹199"
  },
  {
    icon: Shield,
    title: "Premium Care",
    description: "Specialized treatment for luxury fabrics and designer wear.",
    price: "From ₹299"
  }
];

const ServicesSection = () => {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <span className="text-primary font-medium text-sm tracking-widest uppercase">Our Services</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-4 text-foreground">
            Superhero-Level <span className="text-gradient-gold">Cleaning</span>
          </h2>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            From everyday laundry to premium garment care, we've got you covered
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div 
              key={index}
              className="bg-card border border-border rounded-2xl p-8 hover:border-secondary transition-all duration-300 group hover:glow-gold"
            >
              <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center mb-6 group-hover:gradient-ironman transition-all">
                <service.icon className="w-7 h-7 text-primary group-hover:text-white transition-colors" />
              </div>

              <h3 className="text-xl font-bold text-foreground mb-2">{service.title}</h3>
              <p className="text-muted-foreground mb-4">{service.description}</p>
              <p className="text-secondary font-bold text-lg">{service.price}</p>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link to="/pricing">
            <Button size="lg" className="gradient-ironman text-white glow-red">
              View Full Price List
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
